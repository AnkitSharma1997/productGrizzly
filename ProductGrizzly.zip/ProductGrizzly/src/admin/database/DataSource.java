package admin.database;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import pojo.Product;

@Repository("DataSource")
public class DataSource {

	public boolean checkUser(String uname, String pass) {
		Login log;

		// Configuration con = new
		// Configuration().configure("hibernate.cfg.xml");
		// con.addAnnotatedClass(admin.database.Login.class);

		SessionFactory sf = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

		Session session = sf.openSession();
		// System.out.println("hehlfhdflfksflk");
		Transaction tx = session.beginTransaction();
		System.out.println("hehlfhdflfksflk55555" + "  " + uname);
		// Query query = session.createQuery("FROM Login WHERE uname=:uname and
		// pass=:pass");
		// List list = query.list();
		// System.out.println(log);
		log = (Login) session.get(Login.class, uname);
		System.out.println(log);
		// uname.equals(log.getUname()
		// query != null
		tx.commit();
		if (uname.equals(log.getUname())) {

			return true;
		} else {
			return false;
		}

	}

	public void deleteProduct(int id) {
		Login log;
		SessionFactory sf = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		//log = (Login) session.get(Product.class, id);
		Query query = session.createQuery("delete from Product o where o.id=:pid");
		 System.out.println("   deleteProduct   "+id);
		query.setParameter("pid", id);
		int result = query.executeUpdate();
		tx.commit();
	}
	
	
}
