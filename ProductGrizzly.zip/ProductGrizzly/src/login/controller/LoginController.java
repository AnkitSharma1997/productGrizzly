package login.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import admin.database.*;
@Controller
public class LoginController {

	 DataSource login = new DataSource();
	
	@RequestMapping("/")
	public String adminLogin1(){
		 return "index";
	 }
	 @RequestMapping("adminLogin.htm")
    public ModelAndView adminLogin(@RequestParam("t1") String uname, @RequestParam("t2") String pass){
		 //System.out.println("in adminLogin hhhhh");
		
		ModelAndView mv = new ModelAndView();
		if(login.checkUser(uname,pass))
			mv.setViewName("adminLogin");
		else
			mv.setViewName("index");
		 return mv;
		 
	 }
}
