package login.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import admin.database.DataSource;
import pojo.Product;
@Controller
public class ProductController {
	 DataSource login = new DataSource();
		@RequestMapping("addProduct")
		public String damnProduct(){
			 return "productform";
		 }
		 @ModelAttribute("product")
		 public Product addProduct(){
			 Product product  = new Product();
			 return product;
		 }
		 @RequestMapping("delete")
		 public String deleteProducts(@RequestParam("count") String id){
			 //System.out.println("product id  "+id+"    "+Integer.parseInt(id));
			 
			 login.deleteProduct(Integer.parseInt(id));
			 return "adminLogin";
		 }
		 
		 
//		 @RequestMapping("productdetails")
//		 public String detailsOfProduct(@RequestParam("count1") String id){
//			 //System.out.println("product id  "+id+"    "+Integer.parseInt(id));
//			 
//			 login.deleteProduct(Integer.parseInt(id));
//			 return "delete";
//		 }
	
}
